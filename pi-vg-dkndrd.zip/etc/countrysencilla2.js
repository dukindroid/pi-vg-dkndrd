const ciudad = require('./country sencilla.json');

// const { name.official } = ciudad[0];

ciudad[0