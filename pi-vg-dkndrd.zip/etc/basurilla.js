let resultado = JSON.stringify(generos, null, 4);
const resultadoJson = {
  "name": "Puzzle",
  "Videogames": [
    {
      "name": "Portal 2",
      "VideogameGenre": {
        "createdAt": "2022-09-10T10:47:40.659Z",
        "updatedAt": "2022-09-10T10:47:40.659Z",
        "VideogameId": 3,
        "GenreName": "Puzzle"
      }
    },
    {
      "name": "Portal",
          "VideogameGenre": {
            "createdAt": "2022-09-10T10:47:40.667Z",
            "updatedAt": "2022-09-10T10:47:40.667Z",
            "VideogameId": 8,
            "GenreName": "Puzzle"
          }
        },
        {
          "name": "Limbo",
          "VideogameGenre": {
              "createdAt": "2022-09-10T10:47:40.678Z",
              "updatedAt": "2022-09-10T10:47:40.678Z",
              "VideogameId": 15,
              "GenreName": "Puzzle"
            }
          }
        ]
      }



      //  generos.Videogames
      // await Promise.all(re.map( async ( el ) => {
        //   console.log(el.name + '\n'); 
        // }))
        
        //console.log(JSON.stringify(generos, null, 4))
        // console.log(JSON.stringify(generos, null, 4))
// await genresSeed.reduce( async (memo, i) => {
  //   await memo;
//   await Genre.create( { name: memo } )
//   console.log(i);
// }, undefined);ñ

// sequelize.sync({force: true}).then(() => {
  // Genre.create( { name: "Espantoso"} )
  // Genre.create( { name: "Horrible"} )
  // }).then(async () => {
    //   let losGeneros = await Genre.findAll()
    //   console.log(JSON.stringify( losGeneros))
    // })
    
    // console.log(JSON.stringify(genresSeed))
    // let allGenres = ['Tipo de juego'];
/*
sequelize.sync({force: true}).then(() => {
  console.log("Conexión establecida...");
  genresSeed.map((singleGenre) => allGenres.push( Genre.create( { name: singleGenre } ))) 
}).then(() => {
  videogamesSeed.map( async ( oneGame ) => {
    const { name, description, released, rating, platforms, genres } = oneGame;
    const newVideogame = await Videogame.create({ name, description, released, rating, platforms });
    genres.map( async ( genre ) => {
      await newVideogame.addGenre( genre, { through: 'VideogameGenre' })
    })
  })  
}).then( async () => {
  // let allGenres = await Genre.findAll();
  console.log('allGenres: ' + JSON.stringify(Genre.findAll()))

  let allGames = await Videogame.findAll();
  console.log('allGames: ' + JSON.stringify(allGames));
})
*/
// ( async () => {
//   await sequelize.sync({force: true});
//   genresSeed.map( async (singleGenre) => await Genre.create( { name: singleGenre } )) 
//   videogamesSeed.map( async ( oneGame ) => {
//     const { name, description, released, rating, platforms, genres } = oneGame;
//     const newVideogame = await Videogame.create({ name, description, released, rating, platforms });
//     genres.map( async ( genre ) => {
//       await newVideogame.addGenre( genre, { through: 'VideogameGenre' })
//     })
//   })  
//   const puzzleGames = await Genre.findAll({
//     // where: {
//     //   name : 'Puzzle' 
//     // }, 
//     // include: Videogame
//   })
//   console.log(JSON.stringify(puzzleGames))
// })();

/*
sequelize.sync({ force: false }).then(() => {
  // Conexión establecida
  console.log("Conexión establecida...");
}).catch((err) => {
  console.log("PURAS MERMAS!!" + err);
}).then(() => {
  // const Videogame = require('./src/models/Videogame');
}).catch((err)=>{
  console.log(err)

}) 


// const {Videogame, Genre} = require('./src/models')
const genresSeed = require('./src/models/seed/genresSeed');
const videoGamesSeed = require('./src/models/seed/videogamesSeed');



/*
( async () => {
  await sequelize.sync({ force: true })
  genresSeed.map( async (singleGenre) => await Genre.create( { nombre: singleGenre } )) 
  videoGamesSeed.map( async ( oneGame ) => {
    const { name, description, released, rating, platforms, genres } = oneGame;
    const newVideogame = await Videogame.create({ name, description, released, rating, platforms });
    genres.map( async ( genre ) => {
      await newVideogame.addGenre( genre, { through: VideogameGenre })
    })
  })    

  let pruebaGenre = await Genre.findByPk('Puzzle');
  let cuantosJuegosDeAcción = await pruebaGenre.countVideogames();
  
  console.log(`Tenemos ${cuantosJuegosDeAcción} juegos de puzzle`);

})();
  */