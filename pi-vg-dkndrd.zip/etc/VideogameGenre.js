const { Model, DataTypes } = require('sequelize');

class VideogameGenre extends Model {};

module.exports = (sequelize) => {
  return VideogameGenre.init({
  },{
    sequelize,
    timestamps: false
  })
};
