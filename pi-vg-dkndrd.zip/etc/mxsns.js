  /*
  Videogame.getGenres() 
  Videogame.setGenres() 
  Videogame.addGenres() 
  Videogame.addGenre() 
  Videogame.createGenre() 
  Videogame.removeGenre() 
  Videogame.removeGenres() 
  Videogame.hasGenre() 
  Videogame.hasGenres() 
  Videogame.countGenres()

  Genre.getVideogames() 
  Genre.setVideogames() 
  Genre.addVideogames() 
  Genre.addVideogame() 
  Genre.createVideogame() 
  Genre.removeVideogame() 
  Genre.removeVideogames() 
  Genre.hasVideogame() 
  Genre.hasVideogames() 
  Genre.countVideogames()
  const model = Genre;
  for (let assoc of Object.keys(model.associations)) {
    for (let accessor of Object.keys(model.associations[assoc].accessors)) {
      console.log(model.name + '.' + model.associations[assoc].accessors[accessor]+'()');
    }
  }
  */

// const nuevojuego = await Videogame.create({ 
//   nombre: "Jueguito del Javo",
//   descripcion: "Juego de cosas muy extrañas",
//   fechaDeLanzamiento: new Date()
// })
// const unGenero = await Genre.findByPk('Action');
// const esPuzzle = await Genre.findByPk('Puzzle');
// await nuevojuego.addGenre(esDeAccion, {through: VideogameGenre})
// await nuevojuego.addGenre(esPuzzle, {through: VideogameGenre})
// nuevojuego.addGenre( , { through: 'videogameGenres' });
// typeof Videogame;

// Videogame.create({ 
//   nombre: "Minecraft",
//   descripcion: "Es un juego de cubitos.",
//   fechaDeLanzamiento: new Date()
// });
// server.listen(3001, () => {
//   console.log('%s listening at 3001'); // eslint-disable-line no-console
// });
