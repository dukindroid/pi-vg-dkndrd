const express = require('express');
const server = express();
const sequelize = require('./database/db');
require('./src/models');
